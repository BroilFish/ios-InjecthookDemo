//
//  killAntiDebugging.mm
//  killAntiDebugging
//
//  Created by lemon4ex on 16/11/15.
//  Copyright (c) 2016年 __MyCompanyName__. All rights reserved.
//

// CaptainHook by Ryan Petrich
// see https://github.com/rpetrich/CaptainHook/

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "CaptainHook/CaptainHook.h"
#include <sys/sysctl.h>
#include <substrate.h>
#include <mach-o/dyld.h>
#include <string>
#import "SCLAlertView.h"

using namespace std;

// Objective-C runtime hooking using CaptainHook:
//   1. declare class using CHDeclareClass()
//   2. load class using CHLoadClass() or CHLoadLateClass() in CHConstructor
//   3. hook method using CHOptimizedMethod()
//   4. register hook using CHHook() in CHConstructor
//   5. (optionally) call old method using CHSuper()
static int	(*old_sysctl)(int *, u_int, void *, size_t *, void *, size_t);

static int	new_sysctl(int *name, u_int namelen, void *oldp, size_t *oldlenp, void *newp, size_t newlen)
{
    int result = old_sysctl(name,namelen,oldp,oldlenp,newp,newlen);
    if (*oldlenp == sizeof(struct kinfo_proc)) {
        struct kinfo_proc *info = (struct kinfo_proc *)oldp;
        info->kp_proc.p_flag &= ~(P_TRACED);
    }
    return result;
}

static void	 (*old_exit)(int);
static void	 new_exit(int)
{
    
}

typedef int (*ptr_ptrace_t)(int _request, pid_t _pid, caddr_t _addr, int _data);
static ptr_ptrace_t old_ptrace;
static int new_ptrace(int _request, pid_t _pid, caddr_t _addr, int _data)
{
    if(_request == 31) //PT_DENY_ATTACH
    {
        return 0;
    }
    
    return old_ptrace(_request,_pid,_addr,_data);
}

//static int (*old_sub_0A338)(void *arg1,string &arg2);
//static int new_sub_0A338(void *arg1,string &arg2)
//{
//    NSLog(@"%s",arg2.c_str());
//    return old_sub_0A338(arg1,arg2);
//}
//
//static void func_for_add_image(const struct mach_header *mh, intptr_t vmaddr_slide)
//{
//    Dl_info info;
//    dladdr(mh, &info);
//    NSLog(@"baseAddr 0x%x，dylib : %s",mh,info.dli_fname);
//    NSString *dylibPath = [NSString stringWithUTF8String:info.dli_fname]; // 获取dylib的名称，如果是目标dylib，那么可以进行hook了
//    if ([[dylibPath lastPathComponent] isEqualToString:@"XXGamePlugin"]) {
//        // 当解密指定字符串时候，dump出调用堆栈
//        intptr_t *sub_0A338 = (intptr_t *)(vmaddr_slide + 0x0A338 | 0x1); // thumb 模式下需要 |0x1
//        MSHookFunction((void *)sub_0A338, (void *)new_sub_0A338,(void **)&old_sub_0A338);
////        // 干掉证书签名校验sub_AF908和sub_AFE94
////        intptr_t *sub_AF908 = (intptr_t *)(vmaddr_slide + 0xAF908 | 0x1);
////        MSHookFunction((void *)sub_AF908, (void *)new_sub_AF908);
////        intptr_t *sub_AFE94 = (intptr_t *)(vmaddr_slide + 0xAFE94 | 0x1);
////        MSHookFunction((void *)sub_AFE94, (void *)new_sub_AFE94);
//    }
//}
CHDeclareClass(IOSAppDelegate);
CHOptimizedMethod2(self, bool, IOSAppDelegate, application, UIApplication*, application, didFinishLaunchingWithOptions, NSDictionary *, options)
{
    NSLog(@"hook application:didFinishLaunchingWithOptions");
   
    //SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
    //[alert showWaiting:@"Loading" subTitle:@"check your device" closeButtonTitle:@"Done" duration:0.0f];
    //NSLog(@"show waiting");
    bool ret = CHSuper2(IOSAppDelegate, application, application, didFinishLaunchingWithOptions, options);
    UIViewController *vc = nil;
    vc = [UIApplication sharedApplication].keyWindow.rootViewController;
    if(vc)
    {
        NSLog(@"rootviewcontroller class:%@", [vc class]);
        NSLog(@"%@", [NSThread callStackSymbols]);
    }
    else
    {
        id nvc = nil;
        nvc = objc_msgSend(self, @selector(IOSController));
        if(nvc == nil)
        {
            Class vcc = objc_getClass("IOSViewController");
            id nvc = [[vcc alloc] init];
            objc_msgSend(nvc, @selector(loadView));
            NSLog(@"create IOSViewController class");
        }
        id window = objc_msgSend(self, @selector(Window));
        objc_msgSend(window, @selector(setRootViewController:), nvc);
        //[UIApplication sharedApplication].keyWindow.rootViewController = nvc;
    }
    
//    UIAlertController *aler = [UIAlertController alertControllerWithTitle:@"test" message:@"OK" preferredStyle:UIAlertControllerStyleAlert];
//    [aler addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
//    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:aler animated:true completion:nil];
    return ret;
}

CHOptimizedMethod0(self, float, IOSAppDelegate, OSVersion)
{
    return 10.0;
}
CHDeclareClass(IOSViewController);
CHOptimizedMethod0(self, void, IOSViewController, loadView)
{
    CHLog(@"%s", __FUNCTION__);
    CHSuper0(IOSViewController, loadView);
}

CHOptimizedMethod0(self, int64_t, IOSViewController, preferredScreenEdgesDeferringSystemGestures)
{
    CHLog(@"%s", __FUNCTION__);
    return CHSuper0(IOSViewController, preferredScreenEdgesDeferringSystemGestures);
}

CHOptimizedMethod0(self, id, IOSViewController, childViewControllerForScreenEdgesDeferringSystemGestures)
{
    CHLog(@"%s", __FUNCTION__);
    return CHSuper0(IOSViewController, childViewControllerForScreenEdgesDeferringSystemGestures);
}

CHOptimizedMethod0(self, void, IOSViewController, viewDidUnload)
{
    CHLog(@"%s", __FUNCTION__);
    CHSuper0(IOSViewController, viewDidUnload);
}

CHOptimizedMethod0(self, int64_t, IOSViewController, supportedInterfaceOrientations)
{
    CHLog(@"%s", __FUNCTION__);
    return CHSuper0(IOSViewController, supportedInterfaceOrientations);
}

CHOptimizedMethod0(self, bool, IOSViewController, shouldAutorotate)
{
    CHLog(@"%s", __FUNCTION__);
    return CHSuper0(IOSViewController, shouldAutorotate);
}

CHOptimizedMethod0(self, bool, IOSViewController, prefersStatusBarHidden)
{
    CHLog(@"%s", __FUNCTION__);
    return CHSuper0(IOSViewController, prefersStatusBarHidden);
}

CHConstructor // code block that runs immediately upon load
{
	@autoreleasepool
	{
        NSLog(@"===============================");
        NSLog(@"=      killAntiDebugging      =");
        NSLog(@"=         by lemon4ex         =");
        NSLog(@"===============================");
        
        NSLog(@"Hook sysctl function");
        MSHookFunction((void *)sysctl, (void *)new_sysctl, (void **)&old_sysctl);
        NSLog(@"Hook exit function");
        MSHookFunction((void *)exit, (void *)new_exit, (void **)&old_exit);
        
        void* handle = dlopen(0, RTLD_GLOBAL | RTLD_NOW);
        ptr_ptrace_t ptrace = (ptr_ptrace_t)dlsym(handle, "ptrace");
        NSLog(@"Hook ptrace function");
        MSHookFunction((void *)ptrace, (void *)new_ptrace, (void **)&old_ptrace);
        
        CHLoadLateClass(IOSAppDelegate);
        CHHook2(IOSAppDelegate, application, didFinishLaunchingWithOptions);
        CHHook0(IOSAppDelegate, OSVersion);
        
        CHLoadLateClass(IOSViewController);
        CHHook0(IOSViewController, loadView);
        CHHook0(IOSViewController, preferredScreenEdgesDeferringSystemGestures);
        CHHook0(IOSViewController, childViewControllerForScreenEdgesDeferringSystemGestures);
        CHHook0(IOSViewController, supportedInterfaceOrientations);
        CHHook0(IOSViewController, shouldAutorotate);
        CHHook0(IOSViewController, prefersStatusBarHidden);
        CHHook0(IOSViewController, viewDidUnload);
//        _dyld_register_func_for_add_image(func_for_add_image);
	}
}
