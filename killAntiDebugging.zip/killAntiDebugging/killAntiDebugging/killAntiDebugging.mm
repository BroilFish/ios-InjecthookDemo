//
//  killAntiDebugging.mm
//  killAntiDebugging
//
//  Created by lemon4ex on 16/11/15.
//  Copyright (c) 2016年 __MyCompanyName__. All rights reserved.
//

// CaptainHook by Ryan Petrich
// see https://github.com/rpetrich/CaptainHook/

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "CaptainHook/CaptainHook.h"
#include <sys/sysctl.h>
#include <substrate.h>
#include <mach-o/dyld.h>
#include <string>
#import <fishhook.h>
#import <objc/runtime.h>


using namespace std;

// Objective-C runtime hooking using CaptainHook:
//   1. declare class using CHDeclareClass()
//   2. load class using CHLoadClass() or CHLoadLateClass() in CHConstructor
//   3. hook method using CHOptimizedMethod()
//   4. register hook using CHHook() in CHConstructor
//   5. (optionally) call old method using CHSuper()
static int	(*old_sysctl)(int *, u_int, void *, size_t *, void *, size_t);

static int	new_sysctl(int *name, u_int namelen, void *oldp, size_t *oldlenp, void *newp, size_t newlen)
{
    int result = old_sysctl(name,namelen,oldp,oldlenp,newp,newlen);
    if (*oldlenp == sizeof(struct kinfo_proc)) {
        struct kinfo_proc *info = (struct kinfo_proc *)oldp;
        info->kp_proc.p_flag &= ~(P_TRACED);
    }
    return result;
}

static void	 (*old_exit)(int);
static void	 new_exit(int)
{
    
}

typedef int (*ptr_ptrace_t)(int _request, pid_t _pid, caddr_t _addr, int _data);
static ptr_ptrace_t old_ptrace;
static int new_ptrace(int _request, pid_t _pid, caddr_t _addr, int _data)
{
    if(_request == 31) //PT_DENY_ATTACH
    {
        return 0;
    }
    
    return old_ptrace(_request,_pid,_addr,_data);
}


//MediaBox HD
CHDeclareClass(AppDelegate);
//delete banner ad
CHOptimizedMethod0(self, NSString *, AppDelegate, adsNetwork)
{
    NSLog(@"%s", __FUNCTION__);
    return @"";
}

CHOptimizedMethod0(self, NSString *, AppDelegate, fullscreenNetwork)
{
    NSLog(@"%s", __FUNCTION__);
    return @"";
}
//------------------------------------------------------------------
mach_vm_address_t gMainBase = NULL;
typedef int64_t (*fun_BigIntergerAddition)(int64_t a1, int64_t a2, int64_t a3) ;
static int64_t (*orig_BigIntergerSubstraction)(int64_t, int64_t, int64_t);
static int64_t new_BigIntergerSubstraction(int64_t a1, int64_t a2, int64_t a3)
{
    NSLog(@"[hook]%s", __func__);
    int64_t ret = 0;
    if(gMainBase)
    {
        NSLog(@"[hook] jump add");
        mach_vm_address_t addr = gMainBase + 0x2f6958;
        fun_BigIntergerAddition funptr = (fun_BigIntergerAddition)addr;
        ret = funptr(a1, a2, a3);
        //ret = orig_BigIntergerSubstraction(a1, a2, a3);
    }
    NSLog(@"[hook]%s ret:%d", __func__, ret);
    return ret;
}
static void hookBigIntergerSubstraction()
{
    NSLog(@"[hook]%s", __func__);
    if(gMainBase)
    {
        mach_vm_address_t addr = gMainBase + 0x2f6b90;
        NSLog(@"[hook] replace %p ", addr);
        MSHookFunction((void*)addr, (void*)&new_BigIntergerSubstraction, (void**)&orig_BigIntergerSubstraction);
    }
    else
    {
        NSLog(@"[hook]%s failed.", __func__);
    }
}

//youTube++
CHDeclareClass(UAAdManager);
CHOptimizedMethod0(self, bool, UAAdManager, shouldShowAds)
{
    NSLog(@"%s", __FUNCTION__);
    return false;
}

CHDeclareClass(UIImage);
CHOptimizedMethod1(self, id, UIImage, imageNamed, NSString*, name)
{
    NSLog(@"[image]%s", __FUNCTION__);
    static NSString *whitPath = nil;
//    static int scale = 1;
//    if(whitPath)
//    {
//        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
//        NSString *docDir = [paths objectAtIndex:0];
//        whitPath = [NSString stringWithFormat:@"%@/white", docDir];
//        scale = [UIScreen mainScreen].scale;
//    }
//    NSString *imgDocName = name;
//    if(scale > 1)
//    {
//        imgDocName = [NSString stringWithFormat:@"%@@%dx.png", name, scale];
//    }
//    NSString *imagePath = [NSString stringWithFormat:@"%@/%@", whitPath, imgDocName];
//    UIImage *img = [UIImage imageWithContentsOfFile:imagePath];
//    //NSLog(@"[image] %@", imagePath);
//    if(img)
//        return img;
//    else
//        NSLog(@"[image] %@", imagePath);
    return CHSuper1(UIImage, imageNamed, name);
}

UIImage * (*old_UIImage_imageNamed)(id self, SEL cmd, NSString* name);
UIImage * new_UIImage_imageNamed(id self, SEL cmd, NSString* name)
{
    NSLog(@"[image]%s", __FUNCTION__);
//    static NSString *whitPath = nil;
//    static int scale = 1;
//    if(whitPath == nil)
//    {
//        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
//        NSString *docDir = [paths objectAtIndex:0];
//        whitPath = [NSString stringWithFormat:@"%@/white", docDir];
//        scale = [UIScreen mainScreen].scale;
//    }
//    NSString *imgDocName = name;
//    if(scale > 1)
//    {
//        imgDocName = [NSString stringWithFormat:@"%@@%dx.png", name, scale];
//    }
//    NSString *imagePath = [NSString stringWithFormat:@"%@/%@", whitPath, imgDocName];
//    UIImage *img = [UIImage imageWithContentsOfFile:imagePath];
//    //NSLog(@"[image] %@", imagePath);
//    if(img)
//        return img;
//    else
//        NSLog(@"[image] %@", imagePath);
    return old_UIImage_imageNamed(self, cmd, name);
}
void hookImage()
{
    Class Cimage = [UIImage class];
    
}


//---------------------------------------------------------------

id objc_getProperty(id self,  char* cmd, ptrdiff_t offset, BOOL atomic)
{
    if (offset == 0) {
        return object_getClass(self);
    }
    
    // Retain release world
    id *slot = (id*) ((char*)self + offset);
    return *slot;
}


CHDeclareClass(NewDelegate);
CHOptimizedMethod(1, self, void, NewDelegate, didFinishLaunching,id, arg1)
{
    NSLog(@"[kill]______________%s", __FUNCTION__);
    //CHSuper1(NewDelegate, didFinishLaunching,arg1);
    id v4 = [UIApplication sharedApplication];
    [v4 setApplicationIconBadgeNumber:0];
    id v5 = [NSNotificationCenter defaultCenter];
    [v5 addObserver:self selector:(SEL)"onGCLoginDialogDidShow" name:@"SL_GCLoginDialogDidShowNotification" object:0];
    id v6 = [NSNotificationCenter defaultCenter];
    [v6 addObserver:self selector:(SEL)"onGCLoginDialogDidHide" name:@"SL_GCLoginDialogDidHideNotification" object:0];
    NSLog(@"[kill]______________end");
}

CHDeclareClass(GADApplication);
CHOptimizedMethod(0, self, bool, GADApplication, isSplitScreenEnabled)
{
    NSLog(@"[kill]______________%s", __FUNCTION__);
//    UIView * view = [(UIViewController*)self view];
//    [view setHidden:true];
    return 0;
    //CHSuper1(MTGAdWebViewController, viewDidLoad,arg1);
}


CHDeclareClass(MTGVideoAdRequestComposite);
CHOptimizedClassMethod(1, self, BOOL, MTGVideoAdRequestComposite, checkAPIReadyWithUnitId,id, arg1)
{
    //NSLog(@"[kill]______________%s", __FUNCTION__);
//    UIView *view=[(UIViewController*)self view];
//    [view setHidden:true];
    return 0;
}

CHDeclareClass(MTGVideoBaseViewController);
CHOptimizedMethod(0, self, void, MTGVideoBaseViewController, viewDidLoad)
{
    NSLog(@"[kill]______________%s", __FUNCTION__);
//    Class aa=objc_getClass("MTGVideoBaseViewController");
    
    Ivar playIvar=class_getInstanceVariable(self, "_playerCreated");
    //NSLog(@"[kill]===ivar1=%@", object_getIvar(object_getClass(self), playIvar));
    object_setIvar(self, playIvar, @YES);
    NSLog(@"[kill]===ivar2=%@", object_getIvar(self, playIvar));
    
    
    CHSuper0(MTGVideoBaseViewController, viewDidLoad);
}

CHDeclareClass(APPatch);
CHOptimizedClassMethod(2, self, id, APPatch,patchWithOffset,id,arg1,hexValue,id,arg2)
{
    NSLog(@"[kill]______________%s", __FUNCTION__);
    //    UIView *view=[(UIViewController*)self view];
    //    [view setHidden:true];
    NSLog(@"[kill]patchWithOffset=%@,hexValue=%@", arg1, arg2);
    return CHSuper2(APPatch,patchWithOffset,arg1,hexValue,arg2);
}


CHDeclareClass(APMenu);
CHOptimizedMethod(4, self, void, APMenu,addPatchNamed,id,arg3,description,id,arg1,offsets,id,arg2,hexPatches,id,arg4)
{
    NSLog(@"[kill]______________%s", __FUNCTION__);
    //    UIView *view=[(UIViewController*)self view];
    //    [view setHidden:true];
    NSLog(@"[kill]patchWithOffset=%@,hexValue=%@", arg2, arg4);
    return CHSuper4(APMenu,addPatchNamed,arg3,description,arg1,offsets,arg2,hexPatches,arg4);
}


CHDeclareClass(AppsFlyerUtils);
CHOptimizedClassMethod(1, self, id, AppsFlyerUtils, md5,id, arg1)
{
    NSLog(@"[kill] %s",__FUNCTION__);
    id ret = CHSuper1(AppsFlyerUtils, md5, arg1);
    NSLog(@"[kill] md5==%@",ret);
    return ret;
}

//CHDeclareClass(ANSMetadata);
//CHOptimizedMethod(0, self, bool, ANSMetadata, computeIsJailbroken)
//{
//    NSLog(@"[kill] %s",__FUNCTION__);
//    NSLog(@"[kill] %d", CHSuper0(ANSMetadata, computeIsJailbroken));
//    return 0;
//}

CHDeclareClass(GADevice);
CHOptimizedMethod(0, self, bool, GADevice, checkJailbroken)
{
    NSLog(@"[kill] %s",__FUNCTION__);
    NSLog(@"[kill] %d", CHSuper0(GADevice, checkJailbroken));
    return 0;
}

CHOptimizedMethod(0, self, NSNumber *, GADevice, jailBroken)
{
    NSLog(@"[kill] %s",__FUNCTION__);
    NSNumber * a=[NSNumber numberWithInt:0];
    NSLog(@"[kill] %@", CHSuper0(GADevice, jailBroken));
    return a;
}

CHDeclareClass(GAState);
CHOptimizedClassMethod(0,self,bool, GAState, isTVos){
    NSLog(@"[kill] %s",__FUNCTION__);
    NSLog(@"[kill] %d", CHSuper0(GAState, isTVos));
    return 0;
    
}

CHDeclareClass(ANSMetadata);
CHOptimizedMethod(0,self,bool, ANSMetadata, isJailbroken){
    NSLog(@"[kill] %s",__FUNCTION__);
    bool a=CHSuper0(ANSMetadata, isJailbroken);
    NSLog(@"[kill] %d", a);
    return 0;
    
}


//---------------------------------------------------------------
CHConstructor // code block that runs immediately upon load
{
	@autoreleasepool
	{
        NSLog(@"[kill]===============================");
        NSLog(@"[kill]=      killAntiDebugging      =");
        NSLog(@"[kill]=         by huskyGG          =");
        NSLog(@"[kill]===============================");
        

//        NSLog(@"Hook sysctl function");
//        MSHookFunction((void *)sysctl, (void *)new_sysctl, (void **)&old_sysctl);
//        NSLog(@"Hook exit function");
//        MSHookFunction((void *)exit, (void *)new_exit, (void **)&old_exit);
// *)ptrace, (void *)new_ptrace, (void **)&old_ptrace);
        
        //MSHookMessage([UIIm
        //        void* handle = dlopen(0, RTLD_GLOBAL | RTLD_NOW);
        //        ptr_ptrace_t ptrace = (ptr_ptrace_t)dlsym(handle, "ptrace");
        //        NSLog(@"Hook ptrace function");
        //        MSHookFunction((voidage class], @selector(imageNamed:), (void *)new_UIImage_imageNamed, (void **)&old_UIImage_imageNamed);
        //CHLoadLateClass(UIImage);
        //CHClassHook1(UIImage, imageNamed);
        //CHLoadLateClass(UAAdManager);
        //CHHook0(UAAdManager, shouldShowAds);
//        const struct mach_header *mh = _dyld_get_image_header(0);
//        gMainBase = (mach_vm_address_t)mh;
//        NSLog(@"[hook] mh:%p", mh);
//        hookBigIntergerSubstraction();
        
//        CHLoadLateClass(AppDelegate);
//        CHHook0(AppDelegate, adsNetwork);
//        CHHook0(AppDelegate, fullscreenNetwork);
        
//        NSLog(@"[kill]=======================begin");
//        CHLoadLateClass(NewDelegate);
//        //CHHook1(NewDelegate, didFinishLaunching);
//        CHHook2(NewDelegate, alertView, clickedButtonAtIndex);
        
        
        //Hook gettimeofday
//        NSLog(@"[kill]===hook gettimeofday");
//        rebind_symbols((struct rebinding[1]){"gettimeofday", (void *)&new_gettimeofday, (void **)&old_gettimeofday}, 1);
        
        
       //MSHookFunction(&gettimeofday, &new_gettimeofday, &old_gettimeofday);
        
        //hook支付宝步数
//        NSLog(@"[kill]===hook numberOfSteps");
//        CHLoadLateClass(APStepInfo);
//        CHHook0(APStepInfo, numberOfSteps);
        
        //ZEPETO商店解锁版去广告
//        NSLog(@"[kill]==hook MTGVideoAdManagerComposite");
//
//        CHLoadLateClass(GADApplication);
//        CHHook0(GADApplication, isSplitScreenEnabled);
        
        
        //iosgods插件破解修改 (失败)
        //NSLog(@"[kill]=== hook iosgods offset");
        
//        CHLoadLateClass(APPatch);
//        CHHook2(APPatch,patchWithOffset,hexValue);
//        CHLoadLateClass(APMenu);
//        CHHook4(APMenu,addPatchNamed,description,offsets,hexPatches);
        
//        //修改ios内存值
//        bool WriteDataToAddress(int hex,int add)
//        {
//
//
//        }
//
        //魔法时代暗桩
        NSLog(@"[kill] hook in AppsFlyerUtils");
        CHLoadLateClass(AppsFlyerUtils);
        CHHook1(AppsFlyerUtils, md5);
        
//
//        //魔法时代检测越狱
//        NSLog(@"[kill] hook in ANSMetadata");
//        CHLoadLateClass(ANSMetadata);
//        CHHook0(ANSMetadata, computeIsJailbroken);
//
//        CHLoadLateClass(GAState);
//        CHHook0(GAState, isTVos);
//
//        CHLoadLateClass(GADevice);
//        //CHHook0(GADevice, jailBroken);
//
//        CHHook0(GADevice, checkJailbroken);
        
//        NSLog(@"[kill] dsifjosidj");
//        CHLoadLateClass(ANSMetadata);
//        CHHook0(ANSMetadata, isJailbroken);
	}
}
