//
//  Demo.m
//  killAntiDebugging
//
//  Created by TB-Mac-004 on 2019/3/11.
//

#import "Demo.h"
#import <mach/mach.h>

@implementation Demo

//-(bool) writeData:(NSString *)hex toAddress:(int64_t)add
//{
//    NSUInteger len=[hex length];
//    vm_address_t addAslr=calculateAddress();
//    if (vm_protect(mach_task_self_, <#vm_address_t address#>, <#vm_size_t size#>, <#boolean_t set_maximum#>, <#vm_prot_t new_protection#>))
//}


@end

//vm_address_t calculateAddress()
//{
//    
//}
