//
//  Demo.h
//  killAntiDebugging
//
//  Created by TB-Mac-004 on 2019/3/11.
//

#import <Foundation/Foundation.h>

@interface Demo : NSObject

-(bool) writeData:(NSString *)hex toAddress:(int64_t)add;

@end
